package com.heetch.countrypicker;

public interface CountryPickerCallbacks {
    void onCountrySelected(Country country, int i);
}
