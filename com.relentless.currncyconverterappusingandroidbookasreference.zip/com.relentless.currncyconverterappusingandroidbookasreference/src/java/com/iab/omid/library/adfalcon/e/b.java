package com.iab.omid.library.adfalcon.e;

import android.webkit.WebView;
import java.lang.ref.WeakReference;

public class b extends WeakReference {
   public b(WebView var1) {
      super(var1);
   }
}
