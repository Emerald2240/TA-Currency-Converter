package com.iab.omid.library.adfalcon.walking.a;

import org.json.JSONObject;

public class d extends com.iab.omid.library.adfalcon.walking.a.b {
   public d(com.iab.omid.library.adfalcon.walking.a.b.b var1) {
      super(var1);
   }

   protected String a(Object... var1) {
      super.d.a((JSONObject)null);
      return null;
   }

   // $FF: synthetic method
   protected Object doInBackground(Object[] var1) {
      return this.a(var1);
   }
}
