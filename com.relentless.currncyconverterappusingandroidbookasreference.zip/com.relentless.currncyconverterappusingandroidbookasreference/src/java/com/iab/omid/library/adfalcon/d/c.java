package com.iab.omid.library.adfalcon.d;

import android.util.Log;

public final class c {
   public static void a(String var0) {
   }

   public static void a(String var0, Exception var1) {
      if (var1 != null) {
         Log.e("OMIDLIB", var0, var1);
      }

   }
}
