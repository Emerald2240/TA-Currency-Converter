package com.iab.omid.library.adfalcon.a;

public class b {
   public a a() {
      return new a();
   }
}
