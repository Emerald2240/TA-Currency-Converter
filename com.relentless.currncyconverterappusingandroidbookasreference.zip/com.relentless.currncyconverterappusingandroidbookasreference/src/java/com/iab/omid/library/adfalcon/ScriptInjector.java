package com.iab.omid.library.adfalcon;

public final class ScriptInjector {
   private ScriptInjector() {
   }

   public static String injectScriptContentIntoHtml(String var0, String var1) {
      return b.a(var0, var1);
   }
}
