package com.iab.omid.library.adfalcon.c;

public class b {
   private final d a;
   private final c b;

   public b() {
      d var1 = new d();
      this.a = var1;
      this.b = new c(var1);
   }

   public a a() {
      return this.b;
   }

   public a b() {
      return this.a;
   }
}
