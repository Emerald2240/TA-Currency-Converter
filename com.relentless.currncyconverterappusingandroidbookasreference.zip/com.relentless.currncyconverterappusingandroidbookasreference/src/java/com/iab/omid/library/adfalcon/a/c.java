package com.iab.omid.library.adfalcon.a;

public interface c {
   void a(float var1);
}
