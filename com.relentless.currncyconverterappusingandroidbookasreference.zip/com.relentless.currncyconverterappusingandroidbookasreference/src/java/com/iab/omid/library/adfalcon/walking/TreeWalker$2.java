package com.iab.omid.library.adfalcon.walking;

final class TreeWalker$2 implements Runnable {
   public void run() {
      TreeWalker.b(TreeWalker.getInstance());
   }
}
