package com.iab.omid.library.adfalcon.walking.a;

import android.os.AsyncTask;
import java.util.concurrent.ThreadPoolExecutor;
import org.json.JSONObject;

public abstract class b extends AsyncTask {
   private com.iab.omid.library.adfalcon.walking.a.b.a a;
   protected final com.iab.omid.library.adfalcon.walking.a.b.b d;

   public b(com.iab.omid.library.adfalcon.walking.a.b.b var1) {
      this.d = var1;
   }

   public void a(com.iab.omid.library.adfalcon.walking.a.b.a var1) {
      this.a = var1;
   }

   protected void a(String var1) {
      com.iab.omid.library.adfalcon.walking.a.b.a var2 = this.a;
      if (var2 != null) {
         var2.a(this);
      }

   }

   public void a(ThreadPoolExecutor var1) {
      this.executeOnExecutor(var1, new Object[0]);
   }

   // $FF: synthetic method
   protected void onPostExecute(Object var1) {
      this.a((String)var1);
   }

   public interface a {
      void a(com.iab.omid.library.adfalcon.walking.a.b var1);
   }

   public interface b {
      void a(JSONObject var1);

      JSONObject b();
   }
}
