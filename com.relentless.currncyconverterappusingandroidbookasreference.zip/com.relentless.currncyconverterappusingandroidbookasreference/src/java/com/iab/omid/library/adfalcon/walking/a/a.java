package com.iab.omid.library.adfalcon.walking.a;

import java.util.HashSet;
import org.json.JSONObject;

public abstract class a extends com.iab.omid.library.adfalcon.walking.a.b {
   protected final HashSet a;
   protected final JSONObject b;
   protected final long c;

   public a(com.iab.omid.library.adfalcon.walking.a.b.b var1, HashSet var2, JSONObject var3, long var4) {
      super(var1);
      this.a = new HashSet(var2);
      this.b = var3;
      this.c = var4;
   }
}
