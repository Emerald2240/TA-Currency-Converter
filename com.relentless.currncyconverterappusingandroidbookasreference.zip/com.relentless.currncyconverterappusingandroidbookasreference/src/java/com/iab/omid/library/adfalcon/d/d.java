package com.iab.omid.library.adfalcon.d;

public final class d {
   public static long a() {
      return System.nanoTime();
   }
}
