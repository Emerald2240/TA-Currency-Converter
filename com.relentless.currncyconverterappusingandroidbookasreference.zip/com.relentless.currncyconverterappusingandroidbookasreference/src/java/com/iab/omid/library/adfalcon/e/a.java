package com.iab.omid.library.adfalcon.e;

import android.view.View;
import java.lang.ref.WeakReference;

public class a extends WeakReference {
   public a(View var1) {
      super(var1);
   }
}
