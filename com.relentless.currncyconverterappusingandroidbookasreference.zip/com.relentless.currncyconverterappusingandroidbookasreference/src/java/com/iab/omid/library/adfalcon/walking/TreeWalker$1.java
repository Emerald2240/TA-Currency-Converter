package com.iab.omid.library.adfalcon.walking;

class TreeWalker$1 implements Runnable {
   // $FF: synthetic field
   final TreeWalker a;

   TreeWalker$1(TreeWalker var1) {
      this.a = var1;
   }

   public void run() {
      TreeWalker.a(this.a).a();
   }
}
