package com.iab.omid.library.adfalcon.c;

import android.view.View;
import org.json.JSONObject;

public interface a {
   JSONObject a(View var1);

   void a(View var1, JSONObject var2, com.iab.omid.library.adfalcon.c.a.a var3, boolean var4);

   public interface a {
      void a(View var1, com.iab.omid.library.adfalcon.c.a var2, JSONObject var3);
   }
}
