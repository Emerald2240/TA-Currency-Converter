package com.iab.omid.library.adfalcon;

import android.content.Context;
import com.iab.omid.library.adfalcon.b.c;
import com.iab.omid.library.adfalcon.d.e;

public class a {
   private boolean a;

   private void b(Context var1) {
      e.a((Object)var1, "Application Context cannot be null");
   }

   String a() {
      return "1.2.22-Adfalcon";
   }

   void a(Context var1) {
      this.b(var1);
      if (!this.b()) {
         this.a(true);
         com.iab.omid.library.adfalcon.b.e.a().a(var1);
         com.iab.omid.library.adfalcon.b.b.a().a(var1);
         com.iab.omid.library.adfalcon.d.b.a(var1);
         c.a().a(var1);
      }

   }

   void a(boolean var1) {
      this.a = var1;
   }

   boolean a(String var1) {
      return true;
   }

   boolean b() {
      return this.a;
   }
}
