package com.iab.omid.library.adfalcon.walking;

public enum c {
   a,
   b,
   c;

   static {
      c var0 = new c("UNDERLYING_VIEW", 2);
      c = var0;
      c[] var1 = new c[]{a, b, var0};
   }
}
