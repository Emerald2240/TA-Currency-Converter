package com.iab.omid.library.adfalcon.a;

import android.content.Context;
import android.os.Handler;

public class e {
   public d a(Handler var1, Context var2, a var3, c var4) {
      return new d(var1, var2, var3, var4);
   }
}
