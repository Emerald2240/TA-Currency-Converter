package com.noqoush.adfalcon.android.sdk.urlactions;

public class d extends b {
   public boolean a(e param1) {
      // $FF: Couldn't be decompiled
   }

   public boolean b(e param1) throws Exception {
      // $FF: Couldn't be decompiled
   }
}
