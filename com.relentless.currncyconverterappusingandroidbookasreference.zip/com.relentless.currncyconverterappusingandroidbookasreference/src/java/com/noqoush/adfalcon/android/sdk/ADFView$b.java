package com.noqoush.adfalcon.android.sdk;

class ADFView$b implements Runnable {
   // $FF: synthetic field
   final ADFView a;

   ADFView$b(ADFView var1) {
      this.a = var1;
   }

   public void run() {
      ADFView.a(this.a).k();
   }
}
