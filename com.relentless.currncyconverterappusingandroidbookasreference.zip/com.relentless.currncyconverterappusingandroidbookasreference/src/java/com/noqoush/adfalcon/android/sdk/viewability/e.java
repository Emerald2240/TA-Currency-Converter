package com.noqoush.adfalcon.android.sdk.viewability;

import android.content.Context;
import android.webkit.WebView;

public interface e {
   String a(String var1);

   void a();

   void a(Context var1);

   void a(WebView var1);

   void a(WebView var1, String var2);

   void a(Object var1);

   void a(boolean var1);

   void b();

   boolean c();

   String d();
}
