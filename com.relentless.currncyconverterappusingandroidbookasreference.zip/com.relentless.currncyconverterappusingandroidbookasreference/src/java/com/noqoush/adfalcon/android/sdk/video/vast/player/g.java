package com.noqoush.adfalcon.android.sdk.video.vast.player;

public interface g {
   void a();

   void b();

   void c();

   void d();

   void e();

   void f();

   void g();

   void h();
}
