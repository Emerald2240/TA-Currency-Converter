package com.noqoush.adfalcon.android.sdk.video.vast.player;

class h$a$a implements Runnable {
   // $FF: synthetic field
   final h$a a;

   h$a$a(h$a var1) {
      this.a = var1;
   }

   public void run() {
      // $FF: Couldn't be decompiled
   }
}
