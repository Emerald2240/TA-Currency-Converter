package com.noqoush.adfalcon.android.sdk.interstitial.state;

import com.noqoush.adfalcon.android.sdk.ADFInterstitial;
import com.noqoush.adfalcon.android.sdk.m;
import com.noqoush.adfalcon.android.sdk.constant.ADFErrorCode;

public class a implements com.noqoush.adfalcon.android.sdk.interstitial.c {
   public void a(com.noqoush.adfalcon.android.sdk.interstitial.a var1, ADFInterstitial var2) throws Exception {
      throw new Exception("Ad has already been dismissed");
   }

   public void a(com.noqoush.adfalcon.android.sdk.interstitial.a var1, ADFInterstitial var2, ADFErrorCode var3, String var4) throws Exception {
      throw new Exception("Ad has already been dismissed");
   }

   public void b(com.noqoush.adfalcon.android.sdk.interstitial.a var1, ADFInterstitial var2) throws Exception {
      throw new Exception("Ad has already been dismissed");
   }

   public void c(com.noqoush.adfalcon.android.sdk.interstitial.a var1, ADFInterstitial var2) throws Exception {
      var1.b().a();
      if (var1.c().j() != null) {
         var1.c().a((m)null);
      }

      var1.a((com.noqoush.adfalcon.android.sdk.interstitial.c)(new c()));
   }

   public void d(com.noqoush.adfalcon.android.sdk.interstitial.a var1, ADFInterstitial var2) throws Exception {
      throw new Exception("Ad has already been dismissed");
   }
}
