package com.noqoush.adfalcon.android.sdk.video.vast.player;

class h$d$a implements Runnable {
   // $FF: synthetic field
   final h$d a;

   h$d$a(h$d var1) {
      this.a = var1;
   }

   public void run() {
      // $FF: Couldn't be decompiled
   }
}
