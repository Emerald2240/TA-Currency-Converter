package com.noqoush.adfalcon.android.sdk.video.vast.manager;

public interface b {
   void a(String var1);

   void b(String var1);
}
