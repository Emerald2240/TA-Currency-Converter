package com.noqoush.adfalcon.android.sdk.video.vast.model;

class h$a$a implements com.noqoush.adfalcon.android.sdk.urlactions.g {
   // $FF: synthetic field
   final h$a a;

   h$a$a(h$a var1) {
      this.a = var1;
   }

   public void a() {
   }

   public void a(com.noqoush.adfalcon.android.sdk.urlactions.i var1, com.noqoush.adfalcon.android.sdk.urlactions.m var2) {
      this.a.a.a(var1, var2);
   }
}
