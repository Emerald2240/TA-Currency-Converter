package com.noqoush.adfalcon.android.sdk;

public interface ADFAd {
}
