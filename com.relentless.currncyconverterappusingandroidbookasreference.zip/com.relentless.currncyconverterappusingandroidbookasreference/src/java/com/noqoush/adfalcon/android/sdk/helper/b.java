package com.noqoush.adfalcon.android.sdk.helper;

public interface b {
   void a(String var1);

   void b();
}
