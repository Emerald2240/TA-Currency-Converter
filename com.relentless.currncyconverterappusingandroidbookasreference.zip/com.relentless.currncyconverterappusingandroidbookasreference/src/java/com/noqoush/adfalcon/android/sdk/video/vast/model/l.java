package com.noqoush.adfalcon.android.sdk.video.vast.model;

public class l extends g {
   private String c;
   private String d;

   public String c() {
      return this.c;
   }

   public void c(String var1) {
      this.c = var1;
   }

   public String d() {
      return this.d;
   }

   public void d(String var1) {
      this.d = var1;
   }
}
