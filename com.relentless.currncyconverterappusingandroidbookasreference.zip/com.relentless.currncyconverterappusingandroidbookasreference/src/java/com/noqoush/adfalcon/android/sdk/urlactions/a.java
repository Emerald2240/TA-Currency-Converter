package com.noqoush.adfalcon.android.sdk.urlactions;

public class a extends b {
   public boolean a(e var1) {
      try {
         boolean var3 = this.b(var1.b());
         return var3;
      } catch (Exception var4) {
         com.noqoush.adfalcon.android.sdk.util.a.a(var4);
         return false;
      }
   }

   public boolean b(e var1) throws Exception {
      return false;
   }
}
