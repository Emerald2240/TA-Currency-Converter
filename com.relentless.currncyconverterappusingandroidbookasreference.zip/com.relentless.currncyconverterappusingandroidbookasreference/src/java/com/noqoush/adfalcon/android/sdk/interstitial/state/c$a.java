package com.noqoush.adfalcon.android.sdk.interstitial.state;

class c$a implements Runnable {
   // $FF: synthetic field
   final com.noqoush.adfalcon.android.sdk.interstitial.a a;
   // $FF: synthetic field
   final c b;

   c$a(c var1, com.noqoush.adfalcon.android.sdk.interstitial.a var2) {
      this.b = var1;
      this.a = var2;
   }

   public void run() {
      this.a.f().m();
   }
}
