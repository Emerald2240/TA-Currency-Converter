package com.noqoush.adfalcon.android.sdk.urlactions;

public enum i {
   a,
   b;

   static {
      i var0 = new i("OUT_APP", 1);
      b = var0;
      i[] var1 = new i[]{a, var0};
   }
}
