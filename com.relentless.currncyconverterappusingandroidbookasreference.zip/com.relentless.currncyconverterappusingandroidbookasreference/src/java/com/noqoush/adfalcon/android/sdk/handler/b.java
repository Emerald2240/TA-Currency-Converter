package com.noqoush.adfalcon.android.sdk.handler;

import android.content.Context;
import android.view.View;
import com.noqoush.adfalcon.android.sdk.w;
import com.noqoush.adfalcon.android.sdk.nativead.ADFNativeAdStatus;
import com.noqoush.adfalcon.android.sdk.response.k;

public interface b {
   void a(ADFNativeAdStatus var1);

   void a(w.e var1);

   boolean a();

   k b();

   com.noqoush.adfalcon.android.sdk.nativead.a c();

   Context d();

   boolean e();

   View f();
}
