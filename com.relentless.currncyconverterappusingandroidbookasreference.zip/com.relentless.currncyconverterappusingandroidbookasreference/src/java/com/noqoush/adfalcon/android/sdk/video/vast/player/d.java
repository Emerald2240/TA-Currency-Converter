package com.noqoush.adfalcon.android.sdk.video.vast.player;

import com.noqoush.adfalcon.android.sdk.video.vast.model.r;

public interface d {
   void a();

   void a(int var1);

   void a(int var1, int var2);

   void a(r var1);

   void a(boolean var1, boolean var2, int var3);

   void b();

   void b(int var1, int var2);
}
