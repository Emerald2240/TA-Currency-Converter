package com.noqoush.adfalcon.android.sdk.video.vast.model;

public interface w {
   void a(v var1);

   void a(v var1, com.noqoush.adfalcon.android.sdk.urlactions.i var2, com.noqoush.adfalcon.android.sdk.urlactions.m var3);

   void b(v var1);
}
