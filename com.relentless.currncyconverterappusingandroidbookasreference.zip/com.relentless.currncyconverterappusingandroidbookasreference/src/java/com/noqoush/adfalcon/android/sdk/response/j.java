package com.noqoush.adfalcon.android.sdk.response;

public class j extends f {
   private String a;

   public String a() {
      return "MASS";
   }

   public void a(String var1) {
      this.a = var1;
   }

   public String b() {
      return this.a;
   }
}
