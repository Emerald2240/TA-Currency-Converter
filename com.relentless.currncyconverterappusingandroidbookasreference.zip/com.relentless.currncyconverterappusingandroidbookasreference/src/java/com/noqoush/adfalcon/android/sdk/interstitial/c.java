package com.noqoush.adfalcon.android.sdk.interstitial;

import com.noqoush.adfalcon.android.sdk.ADFInterstitial;
import com.noqoush.adfalcon.android.sdk.constant.ADFErrorCode;

public interface c {
   void a(a var1, ADFInterstitial var2) throws Exception;

   void a(a var1, ADFInterstitial var2, ADFErrorCode var3, String var4) throws Exception;

   void b(a var1, ADFInterstitial var2) throws Exception;

   void c(a var1, ADFInterstitial var2) throws Exception;

   void d(a var1, ADFInterstitial var2) throws Exception;
}
