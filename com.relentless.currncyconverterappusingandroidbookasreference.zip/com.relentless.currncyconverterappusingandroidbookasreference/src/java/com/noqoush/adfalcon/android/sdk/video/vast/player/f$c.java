package com.noqoush.adfalcon.android.sdk.video.vast.player;

import android.view.View;
import android.view.View.OnClickListener;

class f$c implements OnClickListener {
   // $FF: synthetic field
   final f a;

   f$c(f var1) {
      this.a = var1;
   }

   public void onClick(View var1) {
      this.a.getTopContainerListener().a();
   }
}
