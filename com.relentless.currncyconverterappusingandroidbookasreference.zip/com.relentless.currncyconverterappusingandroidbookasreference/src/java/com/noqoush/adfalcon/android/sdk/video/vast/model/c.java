package com.noqoush.adfalcon.android.sdk.video.vast.model;

public interface c {
   void a(b var1);

   void a(b var1, com.noqoush.adfalcon.android.sdk.urlactions.i var2, com.noqoush.adfalcon.android.sdk.urlactions.m var3);

   void b(b var1);
}
