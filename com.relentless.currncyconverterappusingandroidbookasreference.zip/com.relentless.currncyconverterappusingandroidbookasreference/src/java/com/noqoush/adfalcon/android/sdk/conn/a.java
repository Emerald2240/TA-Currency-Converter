package com.noqoush.adfalcon.android.sdk.conn;

import android.os.AsyncTask;
import com.noqoush.adfalcon.android.sdk.constant.ADFErrorCode;
import java.net.HttpURLConnection;

public class a {
   private HttpURLConnection a;
   private com.noqoush.adfalcon.android.sdk.conn.b b;
   private a.b c;

   private void a(a.c var1) {
      Exception var10000;
      label61: {
         boolean var10001;
         if (var1 != null) {
            label62: {
               label52:
               try {
                  if (var1.b != null) {
                     break label52;
                  }
                  break label62;
               } catch (Exception var11) {
                  var10000 = var11;
                  var10001 = false;
                  break label61;
               }

               try {
                  if (var1.a == 200) {
                     this.c().a(var1.b);
                     return;
                  }
               } catch (Exception var10) {
                  var10000 = var10;
                  var10001 = false;
                  break label61;
               }

               int var5;
               com.noqoush.adfalcon.android.sdk.conn.b var4;
               try {
                  var4 = this.c();
                  var5 = var1.a;
               } catch (Exception var7) {
                  var10000 = var7;
                  var10001 = false;
                  break label61;
               }

               try {
                  var4.a(var5, "Communication Error", ADFErrorCode.COMMUNICATION_ERROR);
                  return;
               } catch (Exception var6) {
                  var10000 = var6;
                  var10001 = false;
                  break label61;
               }
            }
         }

         com.noqoush.adfalcon.android.sdk.conn.b var3;
         try {
            var3 = this.c();
         } catch (Exception var9) {
            var10000 = var9;
            var10001 = false;
            break label61;
         }

         try {
            var3.a(-1, "No response", ADFErrorCode.COMMUNICATION_ERROR);
            return;
         } catch (Exception var8) {
            var10000 = var8;
            var10001 = false;
         }
      }

      Exception var2 = var10000;
      this.c().a(-1, "Internal Error", ADFErrorCode.GENERIC_SDK_ERROR);
      com.noqoush.adfalcon.android.sdk.util.a.a(var2);
   }

   // $FF: synthetic method
   static void a(a var0, HttpURLConnection var1) {
      var0.a(var1);
   }

   private void a(com.noqoush.adfalcon.android.sdk.conn.b var1) {
      this.b = var1;
   }

   private void a(HttpURLConnection var1) {
      this.a = var1;
   }

   private void b() {
      try {
         if (this.d() != null) {
            this.d().getInputStream().close();
            this.d().disconnect();
            return;
         }
      } catch (Exception var2) {
         com.noqoush.adfalcon.android.sdk.util.a.a(var2);
      }

   }

   private com.noqoush.adfalcon.android.sdk.conn.b c() {
      return this.b;
   }

   private HttpURLConnection d() {
      return this.a;
   }

   public void a() {
      try {
         this.b();
         this.c().b();
      } catch (Exception var2) {
         com.noqoush.adfalcon.android.sdk.util.a.a(var2);
      }
   }

   public void a(HttpURLConnection var1, com.noqoush.adfalcon.android.sdk.conn.b var2) throws Exception {
      if (var1 != null) {
         if (var2 != null) {
            this.a(var2);
            this.c().a();
            a.b var3 = new a.b();
            this.c = var3;
            var3.execute(new HttpURLConnection[]{var1});
         } else {
            throw new Exception("asyncConnListener must not be null");
         }
      } else {
         throw new Exception("HttpGet must not be null");
      }
   }

   private class b extends AsyncTask {
      private b() {
      }

      // $FF: synthetic method
      b(Object var2) {
         this();
      }

      protected a.c a(HttpURLConnection... param1) {
         // $FF: Couldn't be decompiled
      }

      protected void a(a.c var1) {
         a.this.a();
      }

      protected void b(a.c var1) {
         a.this.a(var1);
      }

      protected void onCancelled() {
         a.this.a();
      }
   }

   private class c {
      public int a;
      public String b;

      private c() {
      }

      // $FF: synthetic method
      c(Object var2) {
         this();
      }
   }
}
