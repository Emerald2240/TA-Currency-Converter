package com.noqoush.adfalcon.android.sdk.images;

public enum a {
   a,
   b;

   static {
      a var0 = new a("disable", 1);
      b = var0;
      a[] var1 = new a[]{a, var0};
   }
}
