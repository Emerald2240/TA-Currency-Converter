package com.noqoush.adfalcon.android.sdk.util;

public class b {
   public static String a(String var0) throws Exception {
      return var0;
   }

   public static String a(String param0, int param1) throws Exception {
      // $FF: Couldn't be decompiled
   }

   public static String a(String param0, String param1) throws Exception {
      // $FF: Couldn't be decompiled
   }

   public static String b(String var0) throws Exception {
      return a(var0, (String)null);
   }
}
