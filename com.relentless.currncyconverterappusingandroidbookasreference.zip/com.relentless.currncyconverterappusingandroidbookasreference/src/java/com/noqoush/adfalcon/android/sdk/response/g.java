package com.noqoush.adfalcon.android.sdk.response;

public class g extends f {
   int a;
   String b;

   public String a() {
      StringBuilder var1 = new StringBuilder();
      var1.append("D");
      var1.append(this.b());
      return var1.toString();
   }

   public void a(int var1) {
      this.a = var1;
   }

   public void a(String var1) {
      this.b = var1;
   }

   public int b() {
      return this.a;
   }

   public String c() {
      return this.b;
   }
}
