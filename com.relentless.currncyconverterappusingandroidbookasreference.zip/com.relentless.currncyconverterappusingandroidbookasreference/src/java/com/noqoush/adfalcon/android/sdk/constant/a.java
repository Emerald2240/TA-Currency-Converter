package com.noqoush.adfalcon.android.sdk.constant;

public enum a {
   a,
   b,
   c,
   d;

   static {
      a var0 = new a("AD_UNIT_1024x768", 3);
      d = var0;
      a[] var1 = new a[]{a, b, c, var0};
   }
}
