package com.noqoush.adfalcon.android.sdk.conn;

import com.noqoush.adfalcon.android.sdk.constant.ADFErrorCode;

public interface b {
   void a();

   void a(int var1, String var2, ADFErrorCode var3);

   void a(String var1);

   void b();
}
