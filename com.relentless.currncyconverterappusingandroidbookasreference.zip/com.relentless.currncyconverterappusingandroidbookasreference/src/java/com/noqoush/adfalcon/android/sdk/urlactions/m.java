package com.noqoush.adfalcon.android.sdk.urlactions;

public enum m {
   a,
   b,
   c,
   d,
   e;

   static {
      m var0 = new m("SCHEME", 4);
      e = var0;
      m[] var1 = new m[]{a, b, c, d, var0};
   }
}
