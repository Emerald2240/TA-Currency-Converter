package com.noqoush.adfalcon.android.sdk.urlactions;

public interface g {
   void a();

   void a(i var1, m var2);
}
