package com.noqoush.adfalcon.android.sdk.nativead.assets;

import android.view.View;

public class b extends a {
   public static final String g = "DAA_ICON";

   public b(int var1) throws Exception {
      super(var1, 1, "DAA_ICON", "AdChoices");
   }

   public void a(com.noqoush.adfalcon.android.sdk.conn.c var1) {
   }

   public boolean a(View param1, com.noqoush.adfalcon.android.sdk.response.f param2) {
      // $FF: Couldn't be decompiled
   }
}
