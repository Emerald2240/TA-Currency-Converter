package com.noqoush.adfalcon.android.sdk.viewability;

import android.content.Context;
import android.media.MediaPlayer;
import android.widget.VideoView;
import com.noqoush.adfalcon.android.sdk.video.vast.model.p;
import com.noqoush.adfalcon.android.sdk.video.vast.model.r;

public interface b {
   void a();

   void a(Context var1);

   void a(Context var1, p var2, r var3, int var4, VideoView var5, MediaPlayer var6);

   void a(Double var1);

   void a(Object var1);

   void b();

   void c();

   void d();

   void e();

   void f();

   void g();

   int getDuration();

   void h();

   void i();

   void j();

   void k();

   void l();

   float m();

   void n();

   void o();

   void p();

   void q();

   void r();

   void s();
}
