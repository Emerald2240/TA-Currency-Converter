package com.noqoush.adfalcon.android.sdk.video.vast.manager;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import java.io.File;
import java.util.Calendar;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class c {
   private static final String a = "ADFALCON_VIDEOS_";
   private static final int b = 86400;
   private static Executor c = Executors.newFixedThreadPool(3);

   public static File a(Context var0, String var1) {
      try {
         StringBuilder var2 = new StringBuilder();
         var2.append("ADFALCON_VIDEOS_");
         var2.append(Uri.parse(var1).getLastPathSegment());
         String var6 = var2.toString();
         File var7 = new File(b(var0), var6);
         return var7;
      } catch (Exception var8) {
         com.noqoush.adfalcon.android.sdk.util.a.a(var8);
         return null;
      }
   }

   public static void a(Context var0) {
      Exception var10000;
      label49: {
         boolean var10001;
         File[] var3;
         int var4;
         try {
            File var2 = b(var0);
            if (!var2.exists() || var2.listFiles() == null) {
               return;
            }

            var3 = var2.listFiles();
            var4 = var3.length;
         } catch (Exception var12) {
            var10000 = var12;
            var10001 = false;
            break label49;
         }

         int var5 = 0;

         while(true) {
            if (var5 >= var4) {
               return;
            }

            label39: {
               File var6;
               double var7;
               try {
                  var6 = var3[var5];
                  if (!var6.isFile() || !var6.getName().contains("ADFALCON_VIDEOS_")) {
                     break label39;
                  }

                  var7 = (double)((Calendar.getInstance().getTimeInMillis() - var6.lastModified()) / 1000L);
               } catch (Exception var11) {
                  var10000 = var11;
                  var10001 = false;
                  break;
               }

               if (var7 > 86400.0D) {
                  try {
                     StringBuilder var9 = new StringBuilder();
                     var9.append("remove from cache: ");
                     var9.append(var6.getName());
                     var9.append(" TTL: ");
                     var9.append(h.a(var7));
                     com.noqoush.adfalcon.android.sdk.util.a.a(var9.toString());
                     var6.delete();
                  } catch (Exception var10) {
                     var10000 = var10;
                     var10001 = false;
                     break;
                  }
               }
            }

            ++var5;
         }
      }

      Exception var1 = var10000;
      com.noqoush.adfalcon.android.sdk.util.a.a(var1);
   }

   public static void a(Context var0, String var1, b var2) {
      try {
         if (b(var0, var1)) {
            var2.a(var1);
         } else {
            (new c.a(var0, var1, var2)).executeOnExecutor(c, new String[0]);
         }
      } catch (Exception var4) {
         if (var2 != null) {
            var2.b(var1);
         }

         com.noqoush.adfalcon.android.sdk.util.a.a(var4);
      }
   }

   private static File b(Context var0) {
      File var3;
      Exception var10000;
      label42: {
         boolean var10001;
         try {
            StringBuilder var1 = new StringBuilder();
            var1.append(var0.getCacheDir());
            var1.append(File.separator);
            var1.append("AdFalcon");
            var3 = new File(var1.toString());
            if (var3.exists()) {
               return var3;
            }
         } catch (Exception var12) {
            var10000 = var12;
            var10001 = false;
            break label42;
         }

         int var7 = 0;

         boolean var8;
         do {
            try {
               var8 = var3.mkdir();
            } catch (Exception var11) {
               var10000 = var11;
               var10001 = false;
               break label42;
            }

            ++var7;
         } while(!var8 && var7 < 5);

         if (var8) {
            return var3;
         }

         try {
            File var9 = var0.getFilesDir();
            return var9;
         } catch (Exception var10) {
            var10000 = var10;
            var10001 = false;
         }
      }

      Exception var2 = var10000;
      com.noqoush.adfalcon.android.sdk.util.a.a(var2);
      var3 = var0.getExternalCacheDir();
      return var3;
   }

   private static Boolean b(String param0, File param1) throws Exception {
      // $FF: Couldn't be decompiled
   }

   public static boolean b(Context var0, String var1) {
      File var2 = a(var0, var1);
      return var2 != null && var2.exists();
   }

   private static class a extends AsyncTask {
      private Context a;
      private b b;
      private String c;

      a(Context var1, String var2, b var3) {
         this.a = var1;
         this.c = var2;
         this.b = var3;
      }

      protected Boolean a(String... var1) {
         try {
            Boolean var3 = com.noqoush.adfalcon.android.sdk.video.vast.manager.c.b(this.c, com.noqoush.adfalcon.android.sdk.video.vast.manager.c.a(this.a, this.c));
            return var3;
         } catch (Exception var4) {
            com.noqoush.adfalcon.android.sdk.util.a.a(var4);
            return false;
         }
      }

      protected void a(Boolean var1) {
         try {
            if (var1) {
               this.b.a(this.c);
            } else {
               this.b.b(this.c);
            }
         } catch (Exception var3) {
            com.noqoush.adfalcon.android.sdk.util.a.a(var3);
         }
      }

      protected void onPreExecute() {
      }
   }
}
