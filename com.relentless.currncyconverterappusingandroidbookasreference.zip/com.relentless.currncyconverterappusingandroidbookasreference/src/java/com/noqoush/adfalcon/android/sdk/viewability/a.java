package com.noqoush.adfalcon.android.sdk.viewability;

import android.content.Context;
import com.noqoush.adfalcon.android.sdk.response.k;

public interface a {
   void a();

   void a(Context var1);

   void a(Context var1, k var2);

   void a(Object var1);

   void b();

   void c();

   void d();
}
