package com.noqoush.adfalcon.android.sdk.response;

public class c {
   private String a;
   private boolean b;

   public c(String var1) {
      this.a(var1);
   }

   public String a() {
      return this.a;
   }

   public void a(String var1) {
      this.a = var1;
   }

   public void a(boolean var1) {
      this.b = var1;
   }

   public boolean b() {
      return this.b;
   }
}
