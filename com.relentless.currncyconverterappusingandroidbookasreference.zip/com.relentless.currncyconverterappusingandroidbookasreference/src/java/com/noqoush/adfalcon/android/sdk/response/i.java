package com.noqoush.adfalcon.android.sdk.response;

public class i extends f {
   String a;

   public String a() {
      return "T";
   }

   public void a(String var1) {
      this.a = var1;
   }

   public String b() {
      return this.a;
   }
}
