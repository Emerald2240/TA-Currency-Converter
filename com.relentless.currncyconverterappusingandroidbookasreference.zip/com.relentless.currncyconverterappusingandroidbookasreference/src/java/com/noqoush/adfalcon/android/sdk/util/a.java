package com.noqoush.adfalcon.android.sdk.util;

import com.noqoush.adfalcon.android.sdk.k;

public class a {
   public static boolean a;

   public static void a(Exception var0) {
      try {
         if (a) {
            b(var0.getMessage());
            var0.printStackTrace();
            return;
         }
      } catch (Exception var2) {
      }

   }

   public static void a(String var0) {
      try {
         if (a) {
            k.a(var0);
            return;
         }
      } catch (Exception var2) {
      }

   }

   public static void b(String var0) {
      try {
         if (a) {
            k.b(var0);
            return;
         }
      } catch (Exception var2) {
      }

   }

   public static void c(String var0) {
      try {
         if (a) {
            k.c(var0);
            return;
         }
      } catch (Exception var2) {
      }

   }

   public static void d(String var0) {
      try {
         if (a) {
            k.d(var0);
            return;
         }
      } catch (Exception var2) {
      }

   }

   public static void e(String var0) {
      try {
         if (a) {
            k.e(var0);
            return;
         }
      } catch (Exception var2) {
      }

   }
}
