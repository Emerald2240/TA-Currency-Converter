package com.noqoush.adfalcon.android.sdk.response;

public abstract class f {
   public abstract String a();
}
