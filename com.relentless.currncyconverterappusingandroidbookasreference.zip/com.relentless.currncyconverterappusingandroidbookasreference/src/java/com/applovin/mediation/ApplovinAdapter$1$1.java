package com.applovin.mediation;

class ApplovinAdapter$1$1 implements Runnable {
   // $FF: synthetic field
   final ApplovinAdapter$1 this$1;

   ApplovinAdapter$1$1(ApplovinAdapter$1 var1) {
      this.this$1 = var1;
   }

   public void run() {
      ApplovinAdapter.access$300(this.this$1.this$0).onAdLoaded(this.this$1.this$0);
   }
}
