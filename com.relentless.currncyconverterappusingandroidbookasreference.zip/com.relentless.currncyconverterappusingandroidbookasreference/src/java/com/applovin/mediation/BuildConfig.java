package com.applovin.mediation;

public final class BuildConfig {
   @Deprecated
   public static final String APPLICATION_ID = "com.applovin.mediation";
   public static final String BUILD_TYPE = "release";
   public static final boolean DEBUG = false;
   public static final String FLAVOR = "";
   public static final String LIBRARY_PACKAGE_NAME = "com.applovin.mediation";
   public static final int VERSION_CODE = 9110400;
   public static final String VERSION_NAME = "9.11.4.0";
}
