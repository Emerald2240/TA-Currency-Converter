package com.applovin.impl.adview;

class n$2$1 implements Runnable {
   // $FF: synthetic field
   final n$2 a;

   n$2$1(n$2 var1) {
      this.a = var1;
   }

   public void run() {
      n.a(this.a.c, this.a.a);
   }
}
