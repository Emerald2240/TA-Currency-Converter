package com.applovin.impl.adview;

import android.content.Context;
import com.applovin.adview.AppLovinAdView;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinSdk;

public class l extends AppLovinAdView {
   public l(AppLovinSdk var1, AppLovinAdSize var2, Context var3) {
      super(var1, var2, var3);
   }
}
