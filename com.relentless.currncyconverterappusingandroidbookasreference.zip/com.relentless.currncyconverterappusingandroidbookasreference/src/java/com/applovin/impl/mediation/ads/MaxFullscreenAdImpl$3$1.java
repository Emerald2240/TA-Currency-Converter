package com.applovin.impl.mediation.ads;

class MaxFullscreenAdImpl$3$1 implements Runnable {
   // $FF: synthetic field
   final MaxFullscreenAdImpl$3 a;

   MaxFullscreenAdImpl$3$1(MaxFullscreenAdImpl$3 var1) {
      this.a = var1;
   }

   public void run() {
      MaxFullscreenAdImpl.a(this.a.c, this.a.a, this.a.b);
   }
}
