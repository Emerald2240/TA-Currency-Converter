package com.applovin.impl.mediation.a.a;

import android.text.SpannedString;

public class g extends c {
   public g(String var1) {
      super(c.a.a);
      this.b = new SpannedString(var1);
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder();
      var1.append("SectionListItemViewModel{text=");
      var1.append(this.b);
      var1.append("}");
      return var1.toString();
   }
}
