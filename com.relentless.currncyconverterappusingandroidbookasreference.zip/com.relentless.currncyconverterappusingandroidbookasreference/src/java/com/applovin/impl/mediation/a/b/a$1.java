package com.applovin.impl.mediation.a.b;

import com.applovin.impl.sdk.j;
import com.applovin.impl.sdk.d.x;
import com.applovin.impl.sdk.network.b;
import org.json.JSONObject;

class a$1 extends x {
   // $FF: synthetic field
   final a a;

   a$1(a var1, b var2, j var3, boolean var4) {
      super(var2, var3, var4);
      this.a = var1;
   }

   public void a(int var1) {
      com.applovin.impl.mediation.a.b.a.a(this.a).a(var1);
   }

   public void a(JSONObject var1, int var2) {
      com.applovin.impl.mediation.a.b.a.a(this.a).a(var1, var2);
   }
}
