package com.applovin.impl.mediation.a.a;

import android.content.Context;

public class f {
   private final String a;
   private final String b;
   private final boolean c;

   f(String var1, String var2, Context var3) {
      this.a = var1;
      this.b = var2;
      this.c = com.applovin.impl.sdk.utils.g.a(var1, var3);
   }

   public String a() {
      return this.a;
   }

   public String b() {
      return this.b;
   }

   public boolean c() {
      return this.c;
   }
}
