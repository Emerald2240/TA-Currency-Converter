package com.applovin.impl.sdk.d;

import org.json.JSONObject;

class ab$1 extends x {
   // $FF: synthetic field
   final com.applovin.impl.sdk.network.a.c a;
   // $FF: synthetic field
   final ab c;

   ab$1(ab var1, com.applovin.impl.sdk.network.b var2, com.applovin.impl.sdk.j var3, com.applovin.impl.sdk.network.a.c var4) {
      super(var2, var3);
      this.c = var1;
      this.a = var4;
   }

   public void a(int var1) {
      this.a.a(var1);
   }

   public void a(JSONObject var1, int var2) {
      this.a.a(var1, var2);
   }
}
