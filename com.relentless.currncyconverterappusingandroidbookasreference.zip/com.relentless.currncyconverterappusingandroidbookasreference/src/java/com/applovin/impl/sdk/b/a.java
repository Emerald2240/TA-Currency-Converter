package com.applovin.impl.sdk.b;

public class a extends d {
   public static final d a = a("c_sticky_topics", "safedk_init,max_ad_events,test_mode_enabled,test_mode_networks,send_http_request");
}
