package com.applovin.impl.sdk.d;

import android.net.Uri;
import android.webkit.URLUtil;
import com.applovin.sdk.AppLovinAdLoadListener;
import java.util.Collections;

class h extends c {
   private final com.applovin.impl.a.a c;

   public h(com.applovin.impl.a.a var1, com.applovin.impl.sdk.j var2, AppLovinAdLoadListener var3) {
      super("TaskCacheVastAd", var1, var2, var3);
      this.c = var1;
   }

   // $FF: synthetic method
   static void a(h var0) {
      var0.j();
   }

   private void j() {
      if (this.c.a()) {
         StringBuilder var1 = new StringBuilder();
         var1.append("Begin caching for VAST streaming ad #");
         var1.append(this.a.getAdIdNumber());
         var1.append("...");
         this.a(var1.toString());
         this.d();
         if (this.c.e()) {
            this.i();
         }

         if (this.c.c() == null.a) {
            this.k();
            this.m();
         } else {
            this.l();
         }

         if (!this.c.e()) {
            this.i();
         }

         if (this.c.c() == null.a) {
            this.l();
         } else {
            this.k();
            this.m();
         }
      } else {
         StringBuilder var10 = new StringBuilder();
         var10.append("Begin caching for VAST ad #");
         var10.append(this.a.getAdIdNumber());
         var10.append("...");
         this.a(var10.toString());
         this.d();
         this.k();
         this.l();
         this.m();
         this.i();
      }

      StringBuilder var5 = new StringBuilder();
      var5.append("Finished caching VAST ad #");
      var5.append(this.c.getAdIdNumber());
      this.a(var5.toString());
      long var8 = System.currentTimeMillis() - this.c.getCreatedAtMillis();
      com.applovin.impl.sdk.c.d.a(this.c, this.b);
      com.applovin.impl.sdk.c.d.a(var8, this.c, this.b);
      this.a(this.c);
      this.b();
   }

   private void k() {
      if (!this.c()) {
         label79: {
            String var4;
            label80: {
               String var1;
               if (this.c.aM()) {
                  com.applovin.impl.a.b var2 = this.c.j();
                  if (var2 != null) {
                     com.applovin.impl.a.e var3 = var2.b();
                     if (var3 == null) {
                        var4 = "Failed to retrieve non-video resources from companion ad. Skipping...";
                        break label80;
                     }

                     Uri var5 = var3.b();
                     String var6;
                     if (var5 != null) {
                        var6 = var5.toString();
                     } else {
                        var6 = "";
                     }

                     String var7 = var3.c();
                     if (!URLUtil.isValidUrl(var6) && !com.applovin.impl.sdk.utils.n.b(var7)) {
                        this.c("Companion ad does not have any resources attached. Skipping...");
                        return;
                     }

                     if (var3.a() == com.applovin.impl.a.e.a.b) {
                        StringBuilder var8 = new StringBuilder();
                        var8.append("Caching static companion ad at ");
                        var8.append(var6);
                        var8.append("...");
                        this.a(var8.toString());
                        Uri var12 = this.b(var6, Collections.emptyList(), false);
                        if (var12 != null) {
                           var3.a(var12);
                           break label79;
                        }

                        var4 = "Failed to cache static companion ad";
                        break label80;
                     }

                     if (var3.a() == com.applovin.impl.a.e.a.d) {
                        String var20;
                        if (com.applovin.impl.sdk.utils.n.b(var6)) {
                           StringBuilder var13 = new StringBuilder();
                           var13.append("Begin caching HTML companion ad. Fetching from ");
                           var13.append(var6);
                           var13.append("...");
                           this.a(var13.toString());
                           var7 = this.f(var6);
                           if (!com.applovin.impl.sdk.utils.n.b(var7)) {
                              StringBuilder var17 = new StringBuilder();
                              var17.append("Unable to load companion ad resources from ");
                              var17.append(var6);
                              var4 = var17.toString();
                              break label80;
                           }

                           var20 = "HTML fetched. Caching HTML now...";
                        } else {
                           StringBuilder var21 = new StringBuilder();
                           var21.append("Caching provided HTML for companion ad. No fetch required. HTML: ");
                           var21.append(var7);
                           var20 = var21.toString();
                        }

                        this.a(var20);
                        var3.a(this.a(var7, Collections.emptyList(), this.c));
                        break label79;
                     }

                     if (var3.a() != com.applovin.impl.a.e.a.c) {
                        return;
                     }

                     var1 = "Skip caching of iFrame resource...";
                  } else {
                     var1 = "No companion ad provided. Skipping...";
                  }
               } else {
                  var1 = "Companion ad caching disabled. Skipping...";
               }

               this.a(var1);
               return;
            }

            this.d(var4);
            return;
         }

         this.c.a(true);
      }
   }

   private void l() {
      if (!this.c()) {
         if (this.c.aN()) {
            if (this.c.h() != null) {
               com.applovin.impl.a.k var1 = this.c.i();
               if (var1 != null) {
                  Uri var2 = var1.b();
                  if (var2 != null) {
                     Uri var3 = this.a(var2.toString(), Collections.emptyList(), false);
                     if (var3 != null) {
                        StringBuilder var4 = new StringBuilder();
                        var4.append("Video file successfully cached into: ");
                        var4.append(var3);
                        this.a(var4.toString());
                        var1.a(var3);
                        return;
                     }

                     StringBuilder var7 = new StringBuilder();
                     var7.append("Failed to cache video file: ");
                     var7.append(var1);
                     this.d(var7.toString());
                     return;
                  }
               }
            }
         } else {
            this.a("Video caching disabled. Skipping...");
         }

      }
   }

   private void m() {
      if (!this.c()) {
         String var5;
         if (this.c.aL() != null) {
            StringBuilder var1 = new StringBuilder();
            var1.append("Begin caching HTML template. Fetching from ");
            var1.append(this.c.aL());
            var1.append("...");
            this.a(var1.toString());
            var5 = this.a(this.c.aL().toString(), this.c.F());
         } else {
            var5 = this.c.aK();
         }

         String var6;
         if (com.applovin.impl.sdk.utils.n.b(var5)) {
            com.applovin.impl.a.a var7 = this.c;
            var7.a(this.a(var5, var7.F(), this.c));
            StringBuilder var8 = new StringBuilder();
            var8.append("Finish caching HTML template ");
            var8.append(this.c.aK());
            var8.append(" for ad #");
            var8.append(this.c.getAdIdNumber());
            var6 = var8.toString();
         } else {
            var6 = "Unable to load HTML template";
         }

         this.a(var6);
      }
   }

   public com.applovin.impl.sdk.c.i a() {
      return com.applovin.impl.sdk.c.i.l;
   }

   public void run() {
      super.run();
      h$1 var1 = new h$1(this);
      if (this.a.I()) {
         this.b.K().c().execute(var1);
      } else {
         var1.run();
      }
   }
}
