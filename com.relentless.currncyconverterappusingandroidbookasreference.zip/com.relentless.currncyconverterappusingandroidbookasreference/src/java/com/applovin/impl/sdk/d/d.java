package com.applovin.impl.sdk.d;

import android.net.Uri;
import com.applovin.impl.sdk.AppLovinAdBase;
import com.applovin.sdk.AppLovinAdLoadListener;

public class d extends c {
   private final com.applovin.impl.sdk.ad.a c;
   private boolean d;
   private boolean e;

   public d(com.applovin.impl.sdk.ad.a var1, com.applovin.impl.sdk.j var2, AppLovinAdLoadListener var3) {
      super("TaskCacheAppLovinAd", var1, var2, var3);
      this.c = var1;
   }

   // $FF: synthetic method
   static void a(d var0) {
      var0.j();
   }

   private void j() {
      boolean var1 = this.c.b();
      boolean var2 = this.e;
      if (!var1 && !var2) {
         StringBuilder var9 = new StringBuilder();
         var9.append("Begin processing for non-streaming ad #");
         var9.append(this.c.getAdIdNumber());
         var9.append("...");
         this.a((String)var9.toString());
         this.d();
         this.k();
         this.l();
         this.i();
      } else {
         StringBuilder var3 = new StringBuilder();
         var3.append("Begin caching for streaming ad #");
         var3.append(this.c.getAdIdNumber());
         var3.append("...");
         this.a((String)var3.toString());
         this.d();
         if (var1) {
            if (this.d) {
               this.i();
            }

            this.k();
            if (!this.d) {
               this.i();
            }

            this.l();
         } else {
            this.i();
            this.k();
         }
      }

      long var7 = System.currentTimeMillis() - this.c.getCreatedAtMillis();
      com.applovin.impl.sdk.c.d.a(this.c, this.b);
      com.applovin.impl.sdk.c.d.a(var7, this.c, this.b);
      this.a((AppLovinAdBase)this.c);
      this.b();
   }

   private void k() {
      this.a((String)"Caching HTML resources...");
      String var1 = this.a(this.c.a(), this.c.F(), this.c);
      this.c.a(var1);
      this.c.a(true);
      StringBuilder var2 = new StringBuilder();
      var2.append("Finish caching non-video resources for ad #");
      var2.append(this.c.getAdIdNumber());
      this.a((String)var2.toString());
      com.applovin.impl.sdk.p var5 = this.b.v();
      String var6 = this.f();
      StringBuilder var7 = new StringBuilder();
      var7.append("Ad updated with cachedHTML = ");
      var7.append(this.c.a());
      var5.a(var6, var7.toString());
   }

   private void l() {
      if (!this.c()) {
         Uri var1 = this.e(this.c.e());
         if (var1 != null) {
            this.c.c();
            this.c.a(var1);
         }

      }
   }

   public com.applovin.impl.sdk.c.i a() {
      return com.applovin.impl.sdk.c.i.i;
   }

   public void a(boolean var1) {
      this.d = var1;
   }

   public void b(boolean var1) {
      this.e = var1;
   }

   public void run() {
      super.run();
      d$1 var1 = new d$1(this);
      if (this.a.I()) {
         this.b.K().c().execute(var1);
      } else {
         var1.run();
      }
   }
}
