package com.applovin.impl.sdk.d;

public class i extends a {
   private final <undefinedtype> a;

   public i(com.applovin.impl.sdk.j var1, Object var2) {
      super("TaskCollectAdvertisingId", var1);
      this.a = var2;
   }

   public com.applovin.impl.sdk.c.i a() {
      return com.applovin.impl.sdk.c.i.b;
   }

   public void run() {
      com.applovin.impl.sdk.k.a var1 = this.b.O().d();
      this.a.a(var1);
   }
}
