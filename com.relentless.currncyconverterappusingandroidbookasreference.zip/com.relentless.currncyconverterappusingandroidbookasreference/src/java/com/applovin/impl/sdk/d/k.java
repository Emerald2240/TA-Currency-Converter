package com.applovin.impl.sdk.d;

import android.os.Build.VERSION;
import com.applovin.sdk.AppLovinSdk;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONException;
import org.json.JSONObject;

public class k extends com.applovin.impl.sdk.d.a {
   private static int a = 0;
   private final AtomicBoolean c = new AtomicBoolean();

   public k(com.applovin.impl.sdk.j var1) {
      super("TaskFetchBasicSettings", var1, true);
   }

   private void a(JSONObject var1) {
      AtomicBoolean var2 = this.c;
      boolean var3 = true;
      if (var2.compareAndSet(false, var3)) {
         com.applovin.impl.sdk.utils.h.d(var1, this.b);
         com.applovin.impl.sdk.utils.h.c(var1, this.b);
         if (var1.length() != 0) {
            var3 = false;
         }

         com.applovin.impl.sdk.utils.h.a(var1, var3, this.b);
         com.applovin.impl.mediation.d.b.a(var1, this.b);
         com.applovin.impl.mediation.d.b.b(var1, this.b);
         this.b("Executing initialize SDK...");
         boolean var4 = com.applovin.impl.sdk.utils.i.a(var1, "smd", false, this.b);
         this.b.z().a(var4);
         com.applovin.impl.sdk.utils.h.f(var1, this.b);
         q var5 = new q(this.b);
         this.b.K().a((com.applovin.impl.sdk.d.a)var5);
         com.applovin.impl.sdk.utils.h.e(var1, this.b);
         this.b("Finished executing initialize SDK");
      }

   }

   private String d() {
      return com.applovin.impl.sdk.utils.h.a((String)this.b.a(com.applovin.impl.sdk.b.d.aJ), "5.0/i", this.e());
   }

   private String i() {
      return com.applovin.impl.sdk.utils.h.a((String)this.b.a(com.applovin.impl.sdk.b.d.aK), "5.0/i", this.e());
   }

   public com.applovin.impl.sdk.c.i a() {
      return com.applovin.impl.sdk.c.i.d;
   }

   protected Map b() {
      HashMap var1 = new HashMap();
      var1.put("rid", UUID.randomUUID().toString());
      if (!(Boolean)this.b.a(com.applovin.impl.sdk.b.d.eR)) {
         var1.put("sdk_key", this.b.t());
      }

      Boolean var3 = com.applovin.impl.sdk.g.a(this.g());
      if (var3 != null) {
         var1.put("huc", var3.toString());
      }

      Boolean var4 = com.applovin.impl.sdk.g.b(this.g());
      if (var4 != null) {
         var1.put("aru", var4.toString());
      }

      Boolean var5 = com.applovin.impl.sdk.g.c(this.g());
      if (var5 != null) {
         var1.put("dns", var5.toString());
      }

      return var1;
   }

   protected JSONObject c() {
      JSONObject var1 = new JSONObject();

      try {
         var1.put("sdk_version", AppLovinSdk.VERSION);
         var1.put("build", String.valueOf(131));
         int var5 = 1 + a;
         a = var5;
         var1.put("init_count", String.valueOf(var5));
         var1.put("server_installed_at", com.applovin.impl.sdk.utils.n.e((String)this.b.a(com.applovin.impl.sdk.b.d.ac)));
         if (this.b.H()) {
            var1.put("first_install", true);
         }

         if (!this.b.I()) {
            var1.put("first_install_v2", true);
         }

         String var8 = (String)this.b.a(com.applovin.impl.sdk.b.d.ea);
         if (com.applovin.impl.sdk.utils.n.b(var8)) {
            var1.put("plugin_version", com.applovin.impl.sdk.utils.n.e(var8));
         }

         String var9 = this.b.n();
         if (com.applovin.impl.sdk.utils.n.b(var9)) {
            var1.put("mediation_provider", com.applovin.impl.sdk.utils.n.e(var9));
         }

         com.applovin.impl.mediation.d.c.a var10 = com.applovin.impl.mediation.d.c.a(this.b);
         var1.put("installed_mediation_adapters", var10.a());
         var1.put("uninstalled_mediation_adapter_classnames", var10.b());
         com.applovin.impl.sdk.k.b var13 = this.b.O().c();
         var1.put("package_name", com.applovin.impl.sdk.utils.n.e(var13.c));
         var1.put("app_version", com.applovin.impl.sdk.utils.n.e(var13.b));
         var1.put("debug", com.applovin.impl.sdk.utils.n.e(var13.g));
         var1.put("platform", "android");
         var1.put("os", com.applovin.impl.sdk.utils.n.e(VERSION.RELEASE));
         var1.put("tg", com.applovin.impl.sdk.utils.q.a(com.applovin.impl.sdk.b.f.g, this.b));
         var1.put("ltg", com.applovin.impl.sdk.utils.q.a(com.applovin.impl.sdk.b.f.h, this.b));
         if ((Boolean)this.b.a(com.applovin.impl.sdk.b.d.dV)) {
            var1.put("compass_random_token", this.b.j());
         }

         if ((Boolean)this.b.a(com.applovin.impl.sdk.b.d.dX)) {
            var1.put("applovin_random_token", this.b.k());
            return var1;
         }
      } catch (JSONException var14) {
         this.a("Failed to construct JSON body", var14);
      }

      return var1;
   }

   public void run() {
      Map var1 = this.b();
      JSONObject var2 = this.c();
      com.applovin.impl.sdk.network.b var3 = com.applovin.impl.sdk.network.b.a(this.b).a(this.d()).c(this.i()).a(var1).a(var2).b("POST").a((Object)(new JSONObject())).a((Integer)this.b.a(com.applovin.impl.sdk.b.d.dF)).c((Integer)this.b.a(com.applovin.impl.sdk.b.d.dI)).b((Integer)this.b.a(com.applovin.impl.sdk.b.d.dE)).b(true).a();
      this.b.K().a(new k.a(this.b), r.a.b, 250L + (long)(Integer)this.b.a(com.applovin.impl.sdk.b.d.dE));
      k$1 var4 = new k$1(this, var3, this.b, this.h());
      var4.a(com.applovin.impl.sdk.b.d.aL);
      var4.b(com.applovin.impl.sdk.b.d.aM);
      this.b.K().a((com.applovin.impl.sdk.d.a)var4);
   }

   private class a extends com.applovin.impl.sdk.d.a {
      public a(com.applovin.impl.sdk.j var2) {
         super("TaskTimeoutFetchBasicSettings", var2, true);
      }

      public com.applovin.impl.sdk.c.i a() {
         return com.applovin.impl.sdk.c.i.g;
      }

      public void run() {
         if (!k.this.c.get()) {
            this.d("Timing out fetch basic settings...");
            k.this.a(new JSONObject());
         }

      }
   }
}
