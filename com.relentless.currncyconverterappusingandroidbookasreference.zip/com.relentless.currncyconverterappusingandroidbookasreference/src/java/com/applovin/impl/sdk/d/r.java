package com.applovin.impl.sdk.d;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public class r {
   private final String a = "TaskManager";
   private final com.applovin.impl.sdk.j b;
   private final com.applovin.impl.sdk.p c;
   private final ScheduledThreadPoolExecutor d;
   private final ScheduledThreadPoolExecutor e;
   private final ScheduledThreadPoolExecutor f;
   private final ScheduledThreadPoolExecutor g;
   private final ScheduledThreadPoolExecutor h;
   private final ScheduledThreadPoolExecutor i;
   private final ScheduledThreadPoolExecutor j;
   private final ScheduledThreadPoolExecutor k;
   private final ScheduledThreadPoolExecutor l;
   private final ScheduledThreadPoolExecutor m;
   private final ScheduledThreadPoolExecutor n;
   private final ScheduledThreadPoolExecutor o;
   private final ScheduledThreadPoolExecutor p;
   private final ScheduledThreadPoolExecutor q;
   private final ScheduledThreadPoolExecutor r;
   private final ScheduledThreadPoolExecutor s;
   private final ScheduledThreadPoolExecutor t;
   private final ScheduledThreadPoolExecutor u;
   private final ScheduledThreadPoolExecutor v;
   private final ScheduledThreadPoolExecutor w;
   private final List x = new ArrayList(5);
   private final Object y = new Object();
   private boolean z;

   public r(com.applovin.impl.sdk.j var1) {
      this.b = var1;
      this.c = var1.v();
      this.d = this.a("main");
      this.e = this.a("timeout");
      this.f = this.a("back");
      this.g = this.a("advertising_info_collection");
      this.h = this.a("postbacks");
      this.i = this.a("caching_interstitial");
      this.j = this.a("caching_incentivized");
      this.k = this.a("caching_other");
      this.l = this.a("reward");
      this.m = this.a("mediation_main");
      this.n = this.a("mediation_timeout");
      this.o = this.a("mediation_background");
      this.p = this.a("mediation_postbacks");
      this.q = this.a("mediation_banner");
      this.r = this.a("mediation_interstitial");
      this.s = this.a("mediation_incentivized");
      this.t = this.a("mediation_reward");
      this.u = this.a("auxiliary_operations", (Integer)var1.a(com.applovin.impl.sdk.b.d.cx));
      this.v = this.a("caching_operations", (Integer)var1.a(com.applovin.impl.sdk.b.d.cy));
      this.w = this.a("shared_thread_pool", (Integer)var1.a(com.applovin.impl.sdk.b.d.al));
   }

   private long a(r.a var1) {
      ScheduledThreadPoolExecutor var4;
      long var2;
      if (var1 == r.a.a) {
         var2 = this.d.getTaskCount();
         var4 = this.d;
      } else if (var1 == r.a.b) {
         var2 = this.e.getTaskCount();
         var4 = this.e;
      } else if (var1 == r.a.c) {
         var2 = this.f.getTaskCount();
         var4 = this.f;
      } else if (var1 == r.a.d) {
         var2 = this.g.getTaskCount();
         var4 = this.g;
      } else if (var1 == r.a.e) {
         var2 = this.h.getTaskCount();
         var4 = this.h;
      } else if (var1 == r.a.f) {
         var2 = this.i.getTaskCount();
         var4 = this.i;
      } else if (var1 == r.a.g) {
         var2 = this.j.getTaskCount();
         var4 = this.j;
      } else if (var1 == r.a.h) {
         var2 = this.k.getTaskCount();
         var4 = this.k;
      } else if (var1 == r.a.i) {
         var2 = this.l.getTaskCount();
         var4 = this.l;
      } else if (var1 == r.a.j) {
         var2 = this.m.getTaskCount();
         var4 = this.m;
      } else if (var1 == r.a.k) {
         var2 = this.n.getTaskCount();
         var4 = this.n;
      } else if (var1 == r.a.l) {
         var2 = this.o.getTaskCount();
         var4 = this.o;
      } else if (var1 == r.a.m) {
         var2 = this.p.getTaskCount();
         var4 = this.p;
      } else if (var1 == r.a.n) {
         var2 = this.q.getTaskCount();
         var4 = this.q;
      } else if (var1 == r.a.o) {
         var2 = this.r.getTaskCount();
         var4 = this.r;
      } else if (var1 == r.a.p) {
         var2 = this.s.getTaskCount();
         var4 = this.s;
      } else {
         if (var1 != r.a.q) {
            return 0L;
         }

         var2 = this.t.getTaskCount();
         var4 = this.t;
      }

      return var2 - var4.getCompletedTaskCount();
   }

   private ScheduledThreadPoolExecutor a(String var1) {
      return this.a(var1, 1);
   }

   private ScheduledThreadPoolExecutor a(String var1, int var2) {
      return new ScheduledThreadPoolExecutor(var2, new r.b(var1));
   }

   private void a(final Runnable var1, long var2, final ScheduledExecutorService var4, boolean var5) {
      if (var2 > 0L) {
         if (var5) {
            com.applovin.impl.sdk.utils.d.a(var2, this.b, new Runnable() {
               public void run() {
                  var4.execute(var1);
               }
            });
         } else {
            var4.schedule(var1, var2, TimeUnit.MILLISECONDS);
         }
      } else {
         var4.submit(var1);
      }
   }

   private boolean a(r.c var1) {
      if (var1.c.h()) {
         return false;
      } else {
         Object var2 = this.y;
         synchronized(var2){}

         boolean var10001;
         Throwable var10000;
         label137: {
            try {
               if (this.z) {
                  return false;
               }
            } catch (Throwable var17) {
               var10000 = var17;
               var10001 = false;
               break label137;
            }

            label131:
            try {
               this.x.add(var1);
               return true;
            } catch (Throwable var16) {
               var10000 = var16;
               var10001 = false;
               break label131;
            }
         }

         while(true) {
            Throwable var3 = var10000;

            try {
               throw var3;
            } catch (Throwable var15) {
               var10000 = var15;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public void a(com.applovin.impl.sdk.d.a var1) {
      if (var1 != null) {
         long var2 = System.currentTimeMillis();

         try {
            com.applovin.impl.sdk.p var7 = this.c;
            StringBuilder var8 = new StringBuilder();
            var8.append("Executing ");
            var8.append(var1.f());
            var8.append(" immediately...");
            var7.c("TaskManager", var8.toString());
            var1.run();
            long var12 = System.currentTimeMillis() - var2;
            this.b.M().a(var1.a(), var12);
            com.applovin.impl.sdk.p var14 = this.c;
            StringBuilder var15 = new StringBuilder();
            var15.append(var1.f());
            var15.append(" finished executing...");
            var14.c("TaskManager", var15.toString());
         } catch (Throwable var17) {
            this.c.b(var1.f(), "Task failed execution", var17);
            long var5 = System.currentTimeMillis() - var2;
            this.b.M().a(var1.a(), true, var5);
            return;
         }
      } else {
         this.c.e("TaskManager", "Attempted to execute null task immediately");
      }
   }

   public void a(com.applovin.impl.sdk.d.a var1, r.a var2) {
      this.a(var1, var2, 0L);
   }

   public void a(com.applovin.impl.sdk.d.a var1, r.a var2, long var3) {
      this.a(var1, var2, var3, false);
   }

   public void a(com.applovin.impl.sdk.d.a var1, r.a var2, long var3, boolean var5) {
      if (var1 != null) {
         if (var3 < 0L) {
            StringBuilder var32 = new StringBuilder();
            var32.append("Invalid delay specified: ");
            var32.append(var3);
            throw new IllegalArgumentException(var32.toString());
         } else {
            r.c var7 = new r.c(var1, var2);
            if (!this.a(var7)) {
               long var29;
               Object var28;
               r var27;
               ScheduledThreadPoolExecutor var31;
               if ((Boolean)this.b.a(com.applovin.impl.sdk.b.d.am)) {
                  var31 = this.w;
                  var27 = this;
                  var28 = var1;
                  var29 = var3;
               } else {
                  long var14 = 1L + this.a(var2);
                  com.applovin.impl.sdk.p var16 = this.c;
                  StringBuilder var17 = new StringBuilder();
                  var17.append("Scheduling ");
                  var17.append(var1.f());
                  var17.append(" on ");
                  var17.append(var2);
                  var17.append(" queue in ");
                  var17.append(var3);
                  var17.append("ms with new queue size ");
                  var17.append(var14);
                  var16.b("TaskManager", var17.toString());
                  ScheduledThreadPoolExecutor var26;
                  if (var2 == r.a.a) {
                     var26 = this.d;
                  } else if (var2 == r.a.b) {
                     var26 = this.e;
                  } else if (var2 == r.a.c) {
                     var26 = this.f;
                  } else if (var2 == r.a.d) {
                     var26 = this.g;
                  } else if (var2 == r.a.e) {
                     var26 = this.h;
                  } else if (var2 == r.a.f) {
                     var26 = this.i;
                  } else if (var2 == r.a.g) {
                     var26 = this.j;
                  } else if (var2 == r.a.h) {
                     var26 = this.k;
                  } else if (var2 == r.a.i) {
                     var26 = this.l;
                  } else if (var2 == r.a.j) {
                     var26 = this.m;
                  } else if (var2 == r.a.k) {
                     var26 = this.n;
                  } else if (var2 == r.a.l) {
                     var26 = this.o;
                  } else if (var2 == r.a.m) {
                     var26 = this.p;
                  } else if (var2 == r.a.n) {
                     var26 = this.q;
                  } else if (var2 == r.a.o) {
                     var26 = this.r;
                  } else if (var2 == r.a.p) {
                     var26 = this.s;
                  } else {
                     if (var2 != r.a.q) {
                        return;
                     }

                     var26 = this.t;
                  }

                  var27 = this;
                  var28 = var7;
                  var29 = var3;
                  var31 = var26;
               }

               var27.a((Runnable)var28, var29, var31, var5);
            } else {
               com.applovin.impl.sdk.p var8 = this.c;
               String var9 = var1.f();
               StringBuilder var10 = new StringBuilder();
               var10.append("Task ");
               var10.append(var1.f());
               var10.append(" execution delayed until after init");
               var8.c(var9, var10.toString());
            }
         }
      } else {
         IllegalArgumentException var6 = new IllegalArgumentException("No task specified");
         throw var6;
      }
   }

   public boolean a() {
      return this.z;
   }

   public ScheduledExecutorService b() {
      return this.u;
   }

   public ScheduledExecutorService c() {
      return this.v;
   }

   public void d() {
      // $FF: Couldn't be decompiled
   }

   public void e() {
      Object var1 = this.y;
      synchronized(var1){}

      boolean var10001;
      Throwable var10000;
      label203: {
         Iterator var3;
         try {
            this.z = true;
            var3 = this.x.iterator();
         } catch (Throwable var24) {
            var10000 = var24;
            var10001 = false;
            break label203;
         }

         while(true) {
            try {
               if (!var3.hasNext()) {
                  break;
               }

               r.c var4 = (r.c)var3.next();
               this.a(var4.c, var4.d);
            } catch (Throwable var25) {
               var10000 = var25;
               var10001 = false;
               break label203;
            }
         }

         label188:
         try {
            this.x.clear();
            return;
         } catch (Throwable var23) {
            var10000 = var23;
            var10001 = false;
            break label188;
         }
      }

      while(true) {
         Throwable var2 = var10000;

         try {
            throw var2;
         } catch (Throwable var22) {
            var10000 = var22;
            var10001 = false;
            continue;
         }
      }
   }

   public static enum a {
      a,
      b,
      c,
      d,
      e,
      f,
      g,
      h,
      i,
      j,
      k,
      l,
      m,
      n,
      o,
      p,
      q;

      static {
         r.a[] var0 = new r.a[]{a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q};
      }
   }

   private class b implements ThreadFactory {
      private final String b;

      b(String var2) {
         this.b = var2;
      }

      public Thread newThread(Runnable var1) {
         StringBuilder var2 = new StringBuilder();
         var2.append("AppLovinSdk:");
         var2.append(this.b);
         var2.append(":");
         var2.append(com.applovin.impl.sdk.utils.q.a(r.this.b.t()));
         Thread var7 = new Thread(var1, var2.toString());
         var7.setDaemon(true);
         var7.setPriority(10);
         var7.setUncaughtExceptionHandler(new UncaughtExceptionHandler() {
            public void uncaughtException(Thread var1, Throwable var2) {
               r.this.c.b("TaskManager", "Caught unhandled exception", var2);
            }
         });
         return var7;
      }
   }

   private class c implements Runnable {
      private final String b;
      private final com.applovin.impl.sdk.d.a c;
      private final r.a d;

      c(com.applovin.impl.sdk.d.a var2, r.a var3) {
         this.b = var2.f();
         this.c = var2;
         this.d = var3;
      }

      public void run() {
         long var1 = System.currentTimeMillis();

         long var22;
         com.applovin.impl.sdk.p var24;
         StringBuilder var25;
         label208: {
            label212: {
               Throwable var10000;
               label206: {
                  boolean var10001;
                  label205: {
                     try {
                        com.applovin.impl.sdk.utils.g.a();
                        if (r.this.b.c() && !this.c.h()) {
                           break label205;
                        }
                     } catch (Throwable var56) {
                        var10000 = var56;
                        var10001 = false;
                        break label206;
                     }

                     try {
                        r.this.c.c(this.b, "Task started execution...");
                        this.c.run();
                        long var31 = System.currentTimeMillis() - var1;
                        r.this.b.M().a(this.c.a(), var31);
                        com.applovin.impl.sdk.p var33 = r.this.c;
                        String var34 = this.b;
                        StringBuilder var35 = new StringBuilder();
                        var35.append("Task executed successfully in ");
                        var35.append(var31);
                        var35.append("ms.");
                        var33.c(var34, var35.toString());
                        break label212;
                     } catch (Throwable var55) {
                        var10000 = var55;
                        var10001 = false;
                        break label206;
                     }
                  }

                  label195:
                  try {
                     r.this.c.c(this.b, "Task re-scheduled...");
                     r.this.a(this.c, this.d, 2000L);
                     break label212;
                  } catch (Throwable var54) {
                     var10000 = var54;
                     var10001 = false;
                     break label195;
                  }
               }

               Throwable var3 = var10000;
               boolean var40 = false;

               try {
                  var40 = true;
                  long var14 = System.currentTimeMillis() - var1;
                  r.this.b.M().a(this.c.a(), true, var14);
                  com.applovin.impl.sdk.p var16 = r.this.c;
                  String var17 = this.c.f();
                  StringBuilder var18 = new StringBuilder();
                  var18.append("Task failed execution in ");
                  var18.append(var14);
                  var18.append("ms.");
                  var16.b(var17, var18.toString(), var3);
                  var40 = false;
               } finally {
                  if (var40) {
                     long var5 = r.this.a(this.d) - 1L;
                     com.applovin.impl.sdk.p var7 = r.this.c;
                     StringBuilder var8 = new StringBuilder();
                     var8.append(this.d);
                     var8.append(" queue finished task ");
                     var8.append(this.c.f());
                     var8.append(" with queue size ");
                     var8.append(var5);
                     var7.c("TaskManager", var8.toString());
                  }
               }

               var22 = r.this.a(this.d) - 1L;
               var24 = r.this.c;
               var25 = new StringBuilder();
               break label208;
            }

            var22 = r.this.a(this.d) - 1L;
            var24 = r.this.c;
            var25 = new StringBuilder();
         }

         var25.append(this.d);
         var25.append(" queue finished task ");
         var25.append(this.c.f());
         var25.append(" with queue size ");
         var25.append(var22);
         var24.c("TaskManager", var25.toString());
      }
   }
}
