package com.applovin.impl.sdk.d;

import org.json.JSONObject;

class z$1 implements com.applovin.impl.sdk.network.a.c {
   // $FF: synthetic field
   final z a;

   z$1(z var1) {
      this.a = var1;
   }

   public void a(int var1) {
      this.a.a(var1);
   }

   public void a(JSONObject var1, int var2) {
      this.a.b(var1);
   }
}
