package com.applovin.impl.sdk.d;

import org.json.JSONObject;

class b$1 extends x {
   // $FF: synthetic field
   final b a;

   b$1(b var1, com.applovin.impl.sdk.network.b var2, com.applovin.impl.sdk.j var3) {
      super(var2, var3);
      this.a = var1;
   }

   public void a(int var1) {
      com.applovin.impl.sdk.utils.h.a(var1, this.b);
   }

   public void a(JSONObject var1, int var2) {
      com.applovin.impl.sdk.d.b.a(this.a, var1);
   }
}
