package com.applovin.impl.sdk.utils;

import com.applovin.adview.AppLovinAdView;
import com.applovin.adview.AppLovinAdViewEventListener;
import com.applovin.impl.sdk.AppLovinAdBase;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.MaxRewardedAdListener;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdClickListener;
import com.applovin.sdk.AppLovinAdDisplayListener;
import com.applovin.sdk.AppLovinAdRewardListener;
import com.applovin.sdk.AppLovinAdVideoPlaybackListener;
import com.applovin.sdk.AppLovinPostbackListener;
import com.applovin.sdk.AppLovinSdkUtils;
import java.util.Map;

public class j {
   public static void a(final AppLovinAdViewEventListener var0, final AppLovinAd var1, final AppLovinAdView var2) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.adOpenedFullscreen(j.b(var1), var2);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about fullscreen opened event", var3);
                  return;
               }
            }
         });
      }

   }

   public static void a(final MaxAdListener var0, final MaxAd var1) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.onAdLoaded(var1);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about ad being loaded", var3);
                  return;
               }
            }
         });
      }

   }

   public static void a(final MaxAdListener var0, final MaxAd var1, final int var2) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.onAdDisplayFailed(var1, var2);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about ad failing to display", var3);
                  return;
               }
            }
         });
      }

   }

   public static void a(final MaxAdListener var0, final MaxAd var1, final MaxReward var2) {
      if (var1 != null && var0 instanceof MaxRewardedAdListener) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  ((MaxRewardedAdListener)var0).onUserRewarded(var1, var2);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about user being rewarded", var3);
                  return;
               }
            }
         });
      }

   }

   public static void a(final MaxAdListener var0, final String var1, final int var2) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.onAdLoadFailed(var1, var2);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about ad failing to load", var3);
                  return;
               }
            }
         });
      }

   }

   public static void a(final AppLovinAdClickListener var0, final AppLovinAd var1) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.adClicked(j.b(var1));
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about ad being clicked", var3);
                  return;
               }
            }
         });
      }

   }

   public static void a(final AppLovinAdDisplayListener var0, final AppLovinAd var1) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.adDisplayed(j.b(var1));
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about ad being displayed", var3);
                  return;
               }
            }
         });
      }

   }

   public static void a(final AppLovinAdDisplayListener var0, final String var1) {
      if (var0 instanceof com.applovin.impl.sdk.ad.i) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               ((com.applovin.impl.sdk.ad.i)var0).onAdDisplayFailed(var1);
            }
         });
      }

   }

   public static void a(final AppLovinAdRewardListener var0, final AppLovinAd var1, final int var2) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.validationRequestFailed(j.b(var1), var2);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad reward listener about reward validation request failing", var3);
                  return;
               }
            }
         });
      }

   }

   public static void a(final AppLovinAdRewardListener var0, final AppLovinAd var1, final Map var2) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.userRewardVerified(j.b(var1), var2);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad reward listener about successful reward validation request", var3);
                  return;
               }
            }
         });
      }

   }

   public static void a(final AppLovinAdVideoPlaybackListener var0, final AppLovinAd var1) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.videoPlaybackBegan(j.b(var1));
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about ad playback began", var3);
                  return;
               }
            }
         });
      }

   }

   public static void a(final AppLovinAdVideoPlaybackListener var0, final AppLovinAd var1, final double var2, final boolean var4) {
      if (var1 != null && var0 != null) {
         Runnable var5 = new Runnable() {
            public void run() {
               try {
                  var0.videoPlaybackEnded(j.b(var1), var2, var4);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about ad playback ended", var3);
                  return;
               }
            }
         };
         AppLovinSdkUtils.runOnUiThread(var5);
      }

   }

   public static void a(final AppLovinPostbackListener var0, final String var1) {
      if (var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.onPostbackSuccess(var1);
               } catch (Throwable var4) {
                  StringBuilder var2 = new StringBuilder();
                  var2.append("Unable to notify AppLovinPostbackListener about postback URL (");
                  var2.append(var1);
                  var2.append(") executed");
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", var2.toString(), var4);
                  return;
               }
            }
         });
      }

   }

   public static void a(final AppLovinPostbackListener var0, final String var1, final int var2) {
      if (var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.onPostbackFailure(var1, var2);
               } catch (Throwable var4) {
                  StringBuilder var2x = new StringBuilder();
                  var2x.append("Unable to notify AppLovinPostbackListener about postback URL (");
                  var2x.append(var1);
                  var2x.append(") failing to execute with error code (");
                  var2x.append(var2);
                  var2x.append("):");
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", var2x.toString(), var4);
                  return;
               }
            }
         });
      }

   }

   private static AppLovinAd b(AppLovinAd var0) {
      AppLovinAdBase var1 = (AppLovinAdBase)var0;
      if (var1.getDummyAd() != null) {
         var0 = var1.getDummyAd();
      }

      return (AppLovinAd)var0;
   }

   public static void b(final AppLovinAdViewEventListener var0, final AppLovinAd var1, final AppLovinAdView var2) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.adClosedFullscreen(j.b(var1), var2);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about fullscreen closed event", var3);
                  return;
               }
            }
         });
      }

   }

   public static void b(final MaxAdListener var0, final MaxAd var1) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.onAdDisplayed(var1);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about ad being displayed", var3);
                  return;
               }
            }
         });
      }

   }

   public static void b(final AppLovinAdDisplayListener var0, final AppLovinAd var1) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.adHidden(j.b(var1));
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about ad being hidden", var3);
                  return;
               }
            }
         });
      }

   }

   public static void b(final AppLovinAdRewardListener var0, final AppLovinAd var1, final Map var2) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.userOverQuota(j.b(var1), var2);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad reward listener about exceeding quota", var3);
                  return;
               }
            }
         });
      }

   }

   public static void c(final AppLovinAdViewEventListener var0, final AppLovinAd var1, final AppLovinAdView var2) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.adLeftApplication(j.b(var1), var2);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about application leave event", var3);
                  return;
               }
            }
         });
      }

   }

   public static void c(final MaxAdListener var0, final MaxAd var1) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.onAdHidden(var1);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about ad being hidden", var3);
                  return;
               }
            }
         });
      }

   }

   public static void c(final AppLovinAdRewardListener var0, final AppLovinAd var1, final Map var2) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.userRewardRejected(j.b(var1), var2);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad reward listener about reward validation request being rejected", var3);
                  return;
               }
            }
         });
      }

   }

   public static void d(final MaxAdListener var0, final MaxAd var1) {
      if (var1 != null && var0 != null) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  var0.onAdClicked(var1);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about ad being clicked", var3);
                  return;
               }
            }
         });
      }

   }

   public static void e(final MaxAdListener var0, final MaxAd var1) {
      if (var1 != null && var0 instanceof MaxRewardedAdListener) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  ((MaxRewardedAdListener)var0).onRewardedVideoStarted(var1);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about rewarded video starting", var3);
                  return;
               }
            }
         });
      }

   }

   public static void f(final MaxAdListener var0, final MaxAd var1) {
      if (var1 != null && var0 instanceof MaxRewardedAdListener) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  ((MaxRewardedAdListener)var0).onRewardedVideoCompleted(var1);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about rewarded video completing", var3);
                  return;
               }
            }
         });
      }

   }

   public static void g(final MaxAdListener var0, final MaxAd var1) {
      if (var1 != null && var0 instanceof MaxAdViewAdListener) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  ((MaxAdViewAdListener)var0).onAdExpanded(var1);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about ad being expanded", var3);
                  return;
               }
            }
         });
      }

   }

   public static void h(final MaxAdListener var0, final MaxAd var1) {
      if (var1 != null && var0 instanceof MaxAdViewAdListener) {
         AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
               try {
                  ((MaxAdViewAdListener)var0).onAdCollapsed(var1);
               } catch (Throwable var3) {
                  com.applovin.impl.sdk.p.c("ListenerCallbackInvoker", "Unable to notify ad event listener about ad being collapsed", var3);
                  return;
               }
            }
         });
      }

   }
}
