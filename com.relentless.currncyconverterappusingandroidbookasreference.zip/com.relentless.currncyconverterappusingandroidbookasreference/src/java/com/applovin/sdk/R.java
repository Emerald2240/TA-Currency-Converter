package com.applovin.sdk;

public final class R {
   private R() {
   }

   public static final class color {
      public static final int applovin_sdk_actionBarBackground = 2131034138;
      public static final int applovin_sdk_checkmarkColor = 2131034139;
      public static final int applovin_sdk_colorEdgeEffect = 2131034140;
      public static final int applovin_sdk_disclosureButtonColor = 2131034141;
      public static final int applovin_sdk_listViewBackground = 2131034142;
      public static final int applovin_sdk_listViewSectionTextColor = 2131034143;
      public static final int applovin_sdk_textColorPrimary = 2131034144;
      public static final int applovin_sdk_xmarkColor = 2131034145;

      private color() {
      }
   }

   public static final class dimen {
      public static final int applovin_sdk_actionBarHeight = 2131099728;
      public static final int applovin_sdk_mediationDebuggerDetailListItemTextSize = 2131099729;
      public static final int applovin_sdk_mediationDebuggerSectionHeight = 2131099730;
      public static final int applovin_sdk_mediationDebuggerSectionTextSize = 2131099731;

      private dimen() {
      }
   }

   public static final class drawable {
      public static final int applovin_ic_check_mark = 2131165289;
      public static final int applovin_ic_disclosure_arrow = 2131165290;
      public static final int applovin_ic_x_mark = 2131165291;
      public static final int mute_to_unmute = 2131165465;
      public static final int unmute_to_mute = 2131165570;

      private drawable() {
      }
   }

   public static final class id {
      public static final int imageView = 2131230867;
      public static final int listView = 2131230878;

      private id() {
      }
   }

   public static final class layout {
      public static final int list_item_detail = 2131427368;
      public static final int list_item_right_detail = 2131427369;
      public static final int list_section = 2131427370;
      public static final int mediation_debugger_activity = 2131427371;
      public static final int mediation_debugger_detail_activity = 2131427372;

      private layout() {
      }
   }

   public static final class string {
      public static final int applovin_instructions_dialog_title = 2131689513;
      public static final int applovin_list_item_image_description = 2131689514;

      private string() {
      }
   }

   public static final class style {
      public static final int com_applovin_mediation_MaxDebuggerActivity_ActionBar = 2131755402;
      public static final int com_applovin_mediation_MaxDebuggerActivity_Theme = 2131755403;

      private style() {
      }
   }
}
